//
//  BroadcastSetupViewController.swift
//  tvbroadcastSetupUI
//
//  Created by williamxie on 28/01/2018.
//  Copyright © 2018 williamxie. All rights reserved.
//

import ReplayKit

class BroadcastSetupViewController: UIViewController {
    
    
    
    
    
    
    // MARK: -  life circle

    
    override func loadView() {
        
        // 判断是否登录
        
        
        super.loadView()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    
    // MARK: -  lazy load

    
    
  
}




// MARK: - UI -
extension BroadcastSetupViewController{
    
    
    fileprivate func setupui()  {
    
        
        
        
    }
    
    
    
}

// MARK: - BroadCast Private Method -
extension BroadcastSetupViewController{
    
    // 开启直播
    // Call this method when the user has finished interacting with the view controller and a broadcast stream can start
    func userDidFinishSetup() {
        // URL of the resource where broadcast can be viewed that will be returned to the application
        let broadcastURL = URL(string:"http://apple.com/broadcast/streamID")
        
        // Dictionary with setup information that will be provided to broadcast extension when broadcast is started
        let setupInfo: [String : NSCoding & NSObjectProtocol] = ["broadcastName": "example" as NSCoding & NSObjectProtocol]
        
        // Tell ReplayKit that the extension is finished setting up and can begin broadcasting
        // 调用 extension start broadcast
        self.extensionContext?.completeRequest(withBroadcast: broadcastURL!, setupInfo: setupInfo)
        
    }
    // 取消直播
    func userDidCancelSetup() {
        let error = NSError(domain: "YouAppDomain", code: -1, userInfo: nil)
        // Tell ReplayKit that the extension was cancelled by the user
        self.extensionContext?.cancelRequest(withError: error)
    }
}

// MARK: - Public Method -
extension BroadcastSetupViewController{
    
}

// MARK: - Actions -
extension BroadcastSetupViewController{
    
}

// MARK: - Delegate -
extension BroadcastSetupViewController{
    
}
