//
//  ReplayKitUploader.swift
//  tvbroadcast
//
//  Created by williamxie on 28/01/2018.
//  Copyright © 2018 williamxie. All rights reserved.
//

import UIKit

class ReplayKitUploader {

    static let shared: ReplayKitUploader = ReplayKitUploader()
    
    private init() {
        
    }
    
    
}
