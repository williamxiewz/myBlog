//
//  UIImage+ML.swift
//  HelloWorld
//
//  Created by williamxie on 08/01/2018.
//  Copyright © 2018 williamxie. All rights reserved.
//

import UIKit



extension UIImage{
    
    class func scaleToSize(image:UIImage,size:CGSize)->UIImage{
        UIGraphicsBeginImageContext(size)
        image.draw(in: CGRect(origin: CGPoint.zero, size: size))
        
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return scaledImage!
        
        
    }
    

}
