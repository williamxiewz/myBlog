//
//  ViewController.swift
//  HelloWorld
//
//  Created by williamxie on 08/01/2018.
//  Copyright © 2018 williamxie. All rights reserved.
//

import UIKit
import MetalPerformanceShaders
import MetalKit



class ViewController: UIViewController ,MTKViewDelegate{

    var metalView:MTKView!
    var commandQueue:MTLCommandQueue!
    var sourceTexture: MTLTexture!
    
    func draw(in view: MTKView) {
        let commandBuffer = commandQueue.makeCommandBuffer()
        
        let gaussianblur = MPSImageGaussianBlur(device: view.device!, sigma: self.blurRadius.value)
        
        gaussianblur.encode(commandBuffer: commandBuffer!, sourceTexture: sourceTexture, destinationTexture: (view.currentDrawable?.texture)!)
        
        commandBuffer?.present(view.currentDrawable!)
        commandBuffer?.commit()
    }
    
    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        
    }
    @IBAction func blurRadiusDidChanged(_ sender: Any) {
        metalView.setNeedsDisplay()
    }
    @IBOutlet weak var blurRadius: UISlider!
    
    
    
    func setupMetalView()  {
        metalView = MTKView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
        
        metalView.center = view.center
        metalView.layer.borderColor = UIColor.white.cgColor
        metalView.layer.borderWidth = 5
        metalView.layer.cornerRadius = 20
        metalView.clipsToBounds = true
        view.addSubview(metalView)
        
        // 获取 GPU
        metalView.device = MTLCreateSystemDefaultDevice()
        guard let metalView = metalView , MPSSupportsMTLDevice(metalView.device) else {
            print("不支持 MetalPerformanceShaders")
            return
        }
        
        metalView.delegate = self
        metalView.depthStencilPixelFormat = .depth32Float_stencil8
        metalView.colorPixelFormat = .bgra8Unorm
        metalView.framebufferOnly = false
    }
    
    
    func loadAssets()  {
        
        commandQueue = metalView.device!.makeCommandQueue()
        let textureLoader = MTKTextureLoader(device: metalView.device!)
        let image = UIImage(named:"1")
//        let mirrorImage = UIImage(cgImage: (image?.cgImage)!, scale: 1, orientation: UIImageOrientation.up)
        let scaledImage = UIImage.scaleToSize(image: image!, size: CGSize(width: 900, height: 900))
        let cgImage = scaledImage.cgImage
        // 将图片加载到 metalPerformanceSader的 输入纹理 source texture
        do {
           sourceTexture = try textureLoader.newTexture(cgImage: cgImage!, options: [:])
        } catch let error {
            print(error)
        }
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        setupMetalView()
        loadAssets()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

