//
//  GameViewController.swift
//  ReplayKitDEMO
//
//  Created by williamxie on 28/01/2018.
//  Copyright © 2018 williamxie. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit
import ReplayKit

class GameViewController: UIViewController {

    @IBOutlet weak var liveButton: UIButton!
    @IBOutlet weak var SceneView: SCNView!
    
    var broadcastAVC : RPBroadcastActivityViewController?
    
    var broadcastController : RPBroadcastController?
    
    @IBAction func startLive(_ sender: UIButton) {
        
        RPBroadcastActivityViewController.load { (broadcastActivityViewController, error) in
        
            self.broadcastAVC = broadcastActivityViewController
            self.broadcastAVC?.delegate = self
            
            self.present(self.broadcastAVC!, animated: true, completion: nil)
        }
        
        
    }
    
    
//    @IBAction func startCapture(_ sender: UIButton) {
//
//        // 已经在来时录制
//        if sender.isSelected {
////            // 停止录制 ,显示回放的预览 在预览中 选择
////            RPScreenRecorder.shared().stopRecording(handler: { (previewVc, error) in
////
////                if error != nil{
////                    print(error)
////                }
////
////
////                if previewVc != nil {
////                    previewVc!.previewControllerDelegate = self
////                    self.present(previewVc!, animated: true, completion: nil)
////                }
////
////            })
//
//
//            RPScreenRecorder.shared().stopCapture(handler: { (error) in
//                if error != nil {
//                    print(error)
//                }
//            })
//
//            sender.isSelected = false
//           return
//        }
//
//
//
//
//
//        guard RPScreenRecorder.shared().isAvailable else {
//            print("不支持 replaykit")
//            return
//        }
//        print("支持 replaykit")
//        //
//
//        sender.isSelected = true
//
//
////        RPScreenRecorder.shared().startRecording { (error) in
////            print(error)
////        }
////
//
//
//        RPScreenRecorder.shared().delegate = self
//        RPScreenRecorder.shared().startCapture(handler: { (sample, type, error) in
//
//            if error != nil {
//                print(error)
//                return
//            }
//
//
//            if CMSampleBufferDataIsReady(sample) {
//
//
//            }
//
//
//
//
//
//        }) { (error) in
//
//            if error != nil {
//                print(error)
//            }
//
//        }
//
//
//    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create a new scene
        let scene = SCNScene(named: "art.scnassets/ship.scn")!
        
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)
        
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .omni
        lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        scene.rootNode.addChildNode(lightNode)
        
        // create and add an ambient light to the scene
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        
        // retrieve the ship node
        let ship = scene.rootNode.childNode(withName: "ship", recursively: true)!
        
        // animate the 3d object
        ship.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2, z: 0, duration: 1)))
        
        // retrieve the SCNView
        
        // set the scene to the view
        SceneView.scene = scene
        
        // allows the user to manipulate the camera
        SceneView.allowsCameraControl = true
        
        // show statistics such as fps and timing information
        SceneView.showsStatistics = true
        
        // configure the view
        SceneView.backgroundColor = UIColor.black
        
        // add a tap gesture recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        SceneView.addGestureRecognizer(tapGesture)
        
    }
    
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        // retrieve the SCNView
        
        
        // check what nodes are tapped
        let p = gestureRecognize.location(in: SceneView)
        let hitResults = SceneView.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result = hitResults[0]
            
            // get its material
            let material = result.node.geometry!.firstMaterial!
            
            // highlight it
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            
            // on completion - unhighlight
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                
                material.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            
            material.emission.contents = UIColor.red
            
            SCNTransaction.commit()
        }
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

}


// MARK: - UI -
extension GameViewController:RPBroadcastActivityViewControllerDelegate{
    
    func broadcastActivityViewController(_ broadcastActivityViewController: RPBroadcastActivityViewController, didFinishWith broadcastController: RPBroadcastController?, error: Error?) {
        
        
        self.broadcastAVC?.dismiss(animated: true, completion: nil)
        self.broadcastController = broadcastController
        RPScreenRecorder.shared().isCameraEnabled = true
        RPScreenRecorder.shared().isMicrophoneEnabled = true
//        RPScreenRecorder.shared().cameraPreviewView
        broadcastController?.startBroadcast(handler: { (error) in
            
            guard error == nil else{
                print("有错")
                print(error)
                return
            }
            
            DispatchQueue.main.async {
                self.liveButton.isSelected = true
            }
            
            
            
            
        })

        
    }
    
    
    
}


extension GameViewController : RPScreenRecorderDelegate{
    
    func screenRecorderDidChangeAvailability(_ screenRecorder: RPScreenRecorder) {
        
    }
    
    
    
    
    func screenRecorder(_ screenRecorder: RPScreenRecorder, didStopRecordingWith previewViewController: RPPreviewViewController?, error: Error?) {
        
    }
    
    
    
}
extension GameViewController : RPPreviewViewControllerDelegate{
    
//    func previewControllerDidFinish(_ previewController: RPPreviewViewController) {
//
//
//        previewController.dismiss(animated: true, completion: nil)
//
//
//
//    }
    
    func previewController(_ previewController: RPPreviewViewController, didFinishWithActivityTypes activityTypes: Set<String>) {
        
        
        print(activityTypes)
        previewController.dismiss(animated: true, completion: nil)
        
        
    }
    
}


//
//extension UIButton {
//    
//   @IBInspectable
//    var localizyed:String? {
//    get {
//        return localizyed
//    }
//    set{   localizyed = newValue }
//    }
//    
//    
//}
//
//
